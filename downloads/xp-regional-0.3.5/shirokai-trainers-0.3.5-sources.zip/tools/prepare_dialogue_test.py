"""Prepare a fresh, loopback-only test server; never point at production.
Usage: python3 tools/prepare_dialogue_test.py /workspace/shared/trainers-dialogue-test-...
Requires remapDialogueTestJar and the existing local production Fabric test template.
"""
from pathlib import Path
import sys,shutil,zipfile,json,hashlib
repo=Path(__file__).resolve().parents[1];runtime=Path(sys.argv[1]).resolve()
assert not runtime.exists(),'Fresh disposable test directory required'
base=Path('/workspace/shared/raids-test-server');runtime.mkdir(parents=True)
for name in ['server.jar','libraries','fabric-server-launch.jar']:(runtime/name).symlink_to(base/name,target_is_directory=(base/name).is_dir())
mods=runtime/'mods';mods.mkdir()
for p in (base/'mods').glob('*.jar'):
 if not p.name.startswith('Shirokai-Raids-'):shutil.copy2(p,mods/p.name)
for p in [repo/'fabric/build/libs/shirokai-trainers-0.3.5.jar',repo/'fabric/build/dialogue-test/zorykai-dialogue-test.jar']:
 with zipfile.ZipFile(p) as z:assert 'fabric.mod.json' in z.namelist(),'Finish Gradle build before preparing runtime'
 shutil.copy2(p,mods/p.name)
for name in ['LuckPerms-Fabric-5.4.140.jar','Impactor-Fabric-5.3.5+1.21.1.jar']:shutil.copy2(Path('/workspace/Shirokai-Pass/build/integration-mods')/name,mods/name)
menus=Path('/workspace/Zorykai-menu/dist/v1.1.0/zorykaimenus-1.1.0.jar')
assert hashlib.sha256(menus.read_bytes()).hexdigest()=='9a9b0cb00c1849fc099b94b565482091e8358336529a1e7478d4a70c7f792d3b'
shutil.copy2(menus,mods/menus.name)
(runtime/'eula.txt').write_text('eula=true\n')
(runtime/'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25588\nonline-mode=false\nenforce-secure-profile=false\nview-distance=2\nsimulation-distance=2\ngenerate-structures=false\nlevel-type=minecraft:flat\n')
print(runtime)

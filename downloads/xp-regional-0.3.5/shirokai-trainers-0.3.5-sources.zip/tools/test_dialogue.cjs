// Automated network client, not a graphical Cobblemon client. Native server dialogue state supplies labels/nonces.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),cp=require('node:child_process'),crypto=require('node:crypto');
const mc=require(process.env.MC_PROTOCOL_MODULE),root=process.env.MC_TEST_ROOT;
const customPackets={'1.21':{play:{toClient:{types:{packet_declare_recipes:'restBuffer',packet_entity_metadata:'restBuffer',packet_window_items:'restBuffer',packet_set_slot:'restBuffer'}}}}};
const client=mc.createClient({host:'127.0.0.1',port:25588,username:'DialogTester',version:'1.21.1',auth:'offline',customPackets});
let online=false,ended=false,opens=0,closes=0,windowId=0,title='',nativeOpens=0;const results=[],channels=[];
function text(n){if(!n)return '';if(typeof n==='string')return n;if(n.type==='string')return n.value;if(n.type==='list')return(n.value.value||[]).map(v=>text({type:n.value.type,value:v})).join('');if(n.type==='compound'){const v=n.value;return(v.text?text(v.text):v['']?text(v['']):v.translate?text(v.translate):'')+text(v.extra);}return '';}
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const wait=async(fn,label,timeout=15000)=>{const start=Date.now();while(!fn()){if(ended)throw Error('Disconnected while '+label);if(Date.now()-start>timeout)throw Error('Timeout: '+label);await pause(120);}};
function rcon(s){return cp.execFileSync('python3',[process.env.MC_RCON_HELPER,...s.split(' ')],{env:process.env,timeout:15000}).toString();}
function probe(action='status'){fs.rmSync(path.join(root,'dialogue-probe.json'),{force:true});rcon(`dialogueprobe ${action} DialogTester`);return JSON.parse(fs.readFileSync(path.join(root,'dialogue-probe.json'),'utf8'));}
const pass=s=>{results.push(s);console.log('PASS',s);};
function input(id,value){const bytes=Buffer.from(value,'utf8');const length=[];let n=bytes.length;do{let b=n&127;n>>>=7;if(n)b|=128;length.push(b);}while(n);client.write('custom_payload',{channel:'cobblemon:input_to_dialogue',data:Buffer.concat([Buffer.from(id.replaceAll('-',''),'hex'),Buffer.from(length),bytes])});}
async function choose(value){const s=probe();assert.ok(s.active);const token=s.inputId;input(token,value);await pause(350);return token;}
async function escape(){client.write('custom_payload',{channel:'cobblemon:escape_dialogue',data:Buffer.alloc(0)});await wait(()=>!probe().active,'escape');}
async function interact(legacy=false){await pause(800);const s=probe();client.write('use_entity',{target:legacy?s.legacyId:s.npcId,mouse:0,hand:0,sneaking:false});}
async function open(){await interact();await wait(()=>probe().active&&probe().page==='inicio','native conversation opens');}
client.on('state',s=>{if(s==='configuration')client.write('settings',{locale:'pt_br',viewDistance:2,chatFlags:0,chatColors:true,skinParts:127,mainHand:1,enableTextFiltering:false,enableServerListing:false});});
client.on('ping',p=>client.write('pong',p));client.on('position',p=>client.write('teleport_confirm',{teleportId:p.teleportId}));client.on('login',()=>online=true);client.on('end',()=>ended=true);client.on('error',e=>{console.error(e.message);ended=true;});
client.on('open_window',p=>{opens++;windowId=p.windowId;title=text(p.windowTitle);});client.on('close_window',()=>{closes++;windowId=0;});
client.on('custom_payload',p=>{channels.push(p.channel);if(p.channel==='cobblemon:dialogue_opened')nativeOpens++;});
(async()=>{try{
 await wait(()=>online,'login',60000);await pause(500);probe('seed');let s=probe();assert.equal(s.op,false);let marks=s.markers;
 await interact(true);await wait(()=>probe().markers===marks+1,'legacy command NPC');assert.equal(probe().active,false);marks++;pass('Legacy NPC still executes its direct player command without opening dialogue');
 await open();s=probe();assert.equal(s.markers,marks);assert.equal(s.text,'Olá, DialogTester! O que procura?');assert.equal(s.speaker,'Mercador DialogTester');assert.equal(s.face,s.npcId);assert.equal(s.vertical,false);assert.deepEqual(s.buttons.map(b=>b.label),['Informações','Comprar / Vender','Sair']);await wait(()=>nativeOpens>0,'native opened packet');pass('Real NPC interaction sends native Cobblemon dialogue with personalized text, speaker portrait and three horizontal buttons');
 // Regression: each valid fast click must return a fresh native input, so the graphical client unlocks its buttons.
 const rapidStarted=Date.now();let rapid=s;let quickest=Infinity;
 for(let i=0;i<12;i++){
  const started=Date.now(),oldToken=rapid.inputId,next=rapid.page==='inicio'?'info':'inicio';
  input(oldToken,rapid.page==='inicio'?'inicio:info':'info:voltar');
  await pause(35);rapid=probe();
  assert.equal(rapid.page,next,'rapid page click must not be silently discarded');
  assert.notEqual(rapid.inputId,oldToken,'every accepted page click must refresh the native input');
  quickest=Math.min(quickest,Date.now()-started);
 }
 assert.ok(quickest<250,'regression must exercise clicks below the former 250ms debounce');
 pass('Twelve rapid page changes below 250ms refresh native inputs without locking buttons');
 s=rapid;
 const sameDialogue=s.dialogueId,sameInput=s.inputId,beforeRepeated=nativeOpens;
 for(let i=0;i<3;i++){
  client.write('use_entity',{target:s.npcId,mouse:0,hand:0,sneaking:false});
  await pause(400);
 }
 s=probe();assert.equal(s.dialogueId,sameDialogue);assert.equal(s.inputId,sameInput);assert.equal(nativeOpens,beforeRepeated);
 pass('Repeated NPC interactions keep the existing conversation and native input without reopen packets');
 input(s.inputId,'inicio:info');await pause(35);s=probe();assert.equal(s.page,'info');
 const fastConsole=s.consoleMarkers,fastToken=s.inputId;
 input(fastToken,'info:console');input(fastToken,'info:console');
 await wait(()=>probe().consoleMarkers===fastConsole+1,'rapid terminal command');
 assert.equal(probe().active,false);assert.equal(probe().consoleMarkers,fastConsole+1);
 pass('A terminal command immediately after page navigation executes once and closes despite repeated input');
 await open();s=probe();
 const initial=s.inputId;input(initial,'inicio:unknown');input(crypto.randomUUID(),'inicio:loja');await pause(400);assert.equal(probe().markers,marks);assert.equal(probe().page,'inicio');pass('Unknown option and forged input nonce do not execute actions');
 await choose('inicio:info');s=probe();assert.equal(s.page,'info');assert.equal(s.vertical,true);assert.equal(s.buttons.find(b=>b.value==='info:permitido').enabled,false);assert.equal(s.buttons.find(b=>b.value==='info:proibido').enabled,false);input(initial,'inicio:loja');await pause(350);assert.equal(probe().page,'info');pass('Page navigation uses a new native input nonce, vertical layout for five options, and disables unauthorized actions');
 await choose('info:permitido');assert.equal(probe().markers,marks);assert.equal(probe().op,false);pass('A forged click on a disabled option cannot execute, even through the native disabled-option callback');
 rcon('lp user DialogTester permission set dialogue.test.allowed true');await open();await choose('inicio:info');await wait(()=>probe().buttons.find(b=>b.value==='info:permitido').enabled,'permission grant');const old=await choose('info:permitido');await wait(()=>probe().markers===marks+1,'authorized action');marks++;assert.equal(probe().active,false);input(old,'info:permitido');input(old,'info:permitido');await pause(400);assert.equal(probe().markers,marks);pass('Authorized player command executes once and consumes the conversation before replays');
 await open();await choose('inicio:info');rcon('lp user DialogTester permission set dialogue.test.allowed false');await choose('info:permitido');assert.equal(probe().markers,marks);pass('Permission revoked while the conversation is open is checked again at button use');
 await open();await choose('inicio:info');const beforeConsole=probe().consoleMarkers;await choose('info:console');await wait(()=>probe().consoleMarkers===beforeConsole+1,'configured console action');assert.equal(probe().op,false);pass('Explicit console button runs as console without granting OP to the player');
 await open();await choose('inicio:info');await choose('info:proibido');assert.equal(probe().op,false);pass('A player-executor command never gains console privileges');
 await open();const distant=probe().inputId;rcon('tp DialogTester 40 200 0');input(distant,'inicio:loja');await wait(()=>!probe().active,'distance invalidation');assert.equal(probe().markers,marks);rcon('tp DialogTester 0.5 200 0.5');pass('Moving away invalidates the session before an action can run');
 await open();probe('expire');await wait(()=>!probe().active,'timeout');pass('Expired conversation is closed without executing buttons');
 await open();probe('replace');await pause(1500);assert.equal(probe().page,'foreign');await escape();pass('Cleanup of an old session does not close another mod native dialogue that replaced it');
 await open();const file=path.join(root,'config/shirokai_trainers/dialogues/integration.json'),original=fs.readFileSync(file);fs.writeFileSync(file,'{"schemaVersion":999}');rcon('traineradmin npc dialogue-reload');assert.equal(probe().active,true);assert.equal(probe().page,'inicio');fs.writeFileSync(file,original);rcon('traineradmin npc dialogue-reload');await wait(()=>!probe().active,'successful reload closes stale session');pass('Invalid JSON leaves the live configuration intact; successful reload discards stale conversations');
 await open();const npcFile=path.join(root,'config/shirokai_trainers/npcs.json'),registry=JSON.parse(fs.readFileSync(npcFile,'utf8'));registry.npcs.find(n=>n.id==='dialogue_test').dialogue=null;fs.writeFileSync(npcFile,JSON.stringify(registry));rcon('traineradmin npc reload');await wait(()=>!probe().active,'JSON binding reload');await interact();await wait(()=>probe().markers===marks+1,'restore original click');marks++;assert.equal(probe().active,false);rcon('traineradmin npc dialogue dialogue_test integration');pass('NPC bindings can be edited in JSON and disabling dialogue restores the original direct command');
 await open();const beforeShop=opens;await choose('inicio:loja');await wait(()=>opens>beforeShop&&probe().screen.includes('com.zorykai'),'real Zorykai menu opens');const shopWindow=windowId,shopCloses=closes;await pause(1200);assert.equal(probe().active,false);assert.equal(windowId,shopWindow);assert.equal(closes,shopCloses);pass('Native dialogue closes before the real ZorykaiMenus 1.1.0 inventory opens, without closing the inventory afterward');
 await open();await choose('inicio:sair');await wait(()=>!probe().active,'close button');pass('Close button ends only the conversation');
 await open();await choose('inicio:info');await choose('info:batalhar');await wait(()=>probe().battle,'real Cobblemon battle starts');assert.equal(probe().active,false);pass('Battle button delegates to the existing Trainers service and creates a real Cobblemon battle');
 fs.writeFileSync(path.join(root,'dialogue-test-result.json'),JSON.stringify({passed:true,scenarios:results.length,tcpClients:1,humanClients:0,zorykaiMenus:'1.1.0',cobblemon:'1.8.3',nativeDialoguePackets:nativeOpens,results},null,2));client.end();
}catch(e){console.error(e.stack);console.error('Last state',JSON.stringify({opens,closes,windowId,title,channels:channels.slice(-12)}));client.end();process.exitCode=1;}})();

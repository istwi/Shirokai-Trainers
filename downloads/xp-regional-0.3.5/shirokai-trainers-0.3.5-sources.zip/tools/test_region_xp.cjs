// Real TCP player + console-only test fixture; no graphical client.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),cp=require('node:child_process');
const mc=require(process.env.MC_PROTOCOL_MODULE),root=process.env.MC_TEST_ROOT;
const customPackets={'1.21':{play:{toClient:{types:{packet_declare_recipes:'restBuffer',packet_entity_metadata:'restBuffer',packet_window_items:'restBuffer',packet_set_slot:'restBuffer'}}}}};
const c=mc.createClient({host:'127.0.0.1',port:25588,username:'XpTester',version:'1.21.1',auth:'offline',customPackets});
let online=false,ended=false;const results=[];const pause=ms=>new Promise(r=>setTimeout(r,ms));
const wait=async(fn,label,t=20000)=>{const start=Date.now();while(!fn()){if(ended)throw Error('Disconnected: '+label);if(Date.now()-start>t)throw Error('Timeout: '+label);await pause(200);}};
function rcon(s){return cp.execFileSync('python3',[process.env.MC_RCON_HELPER,...s.split(' ')],{env:process.env,timeout:15000}).toString();}
function probe(action='status'){fs.rmSync(path.join(root,'region-xp-probe.json'),{force:true});rcon(`regionxpprobe ${action} XpTester`);const s=JSON.parse(fs.readFileSync(path.join(root,'region-xp-probe.json'),'utf8'));assert.equal(s.error,undefined,s.error);return s;}
async function start(action){probe('stop');await wait(()=>!probe().busy,'native recall cleanup');return probe(action);}
const pass=s=>{results.push(s);console.log('PASS',s);};
c.on('state',s=>{if(s==='configuration')c.write('settings',{locale:'pt_br',viewDistance:2,chatFlags:0,chatColors:true,skinParts:127,mainHand:1,enableTextFiltering:false,enableServerListing:false});});c.on('ping',p=>c.write('pong',p));c.on('position',p=>c.write('teleport_confirm',{teleportId:p.teleportId}));c.on('login',()=>online=true);c.on('end',()=>ended=true);c.on('error',e=>{console.error(e);ended=true;});
(async()=>{try{
 await wait(()=>online,'join',60000);await pause(500);let s=probe('seed');const guard=s.guard;assert.equal(s.op,false);const inventory=s.inventory;let normal=100,bonus=guard?200:100;
 await start('inside');assert.equal(probe('battle-xp').delta,bonus);pass(guard?'Both actual NPC and player inside the Guard region: native Pokemon.addExperience awards 200 from 100':'No Guard installed: NPC battles and native Pokemon.addExperience remain at 100 without linkage errors');
 assert.equal(probe('command-xp').delta,100);assert.equal(probe('candy-xp').delta,100);pass('Command and candy experience sources receive no regional multiplier');
 assert.equal(probe('foreign-owner').delta,100);pass('A Pokemon without the battle player owner receives no bonus');
 probe('reload3');assert.equal(probe('battle-xp').delta,bonus);await start('startagain');assert.equal(probe('battle-xp').delta,guard?300:100);pass('Reload preserves the original battle snapshot and applies the new multiplier only to subsequent battles');
 await start('oneoutside');assert.equal(probe('battle-xp').delta,100);pass('NPC outside and player inside receives normal experience');
 await start('bothoutside');assert.equal(probe('battle-xp').delta,100);pass('Player and NPC outside the region receive normal experience');
 await start('inside');await start('remote');assert.equal(probe('battle-xp').delta,100);pass('Remote trainer battle without an actual NPC origin receives normal experience');
 for(const [action,label] of [['wrongdimension','Different dimension'],['wrongtrainer','Trainer filter mismatch'],['disabled','Feature disabled'],['missingregion','Missing Guard region']]){
  await start(action);assert.equal(probe('battle-xp').delta,100);pass(label+' receives normal experience');
 }
 await start('overlap');assert.equal(probe('battle-xp').delta,guard?300:100);pass('Overlapping regions select the highest multiplier and never stack');
 await start('fractional');assert.equal(probe('battle-xp').delta,guard?150:100);pass('Fractional multiplier uses the configured native integer experience');
 await start('boundary');assert.equal(probe('battle-xp').delta,100);pass('Negative fractional coordinates are floored and do not cross the Guard block boundary');
 probe('restorebounds');await start('inside');const config=path.join(root,'config/shirokai_trainers/xp-regions.json'),good=fs.readFileSync(config);fs.rmSync(config+'.bak',{force:true});fs.writeFileSync(config,'{"schemaVersion":1,"enabled":true,"regions":[{"region":"__global__","dimension":"minecraft:overworld","multiplier":999}]}');rcon('traineradmin reload');assert.equal(probe('battle-xp').delta,bonus);fs.writeFileSync(config,good);rcon('traineradmin reload');pass('Invalid region configuration is rejected without replacing the live configuration or battle snapshot');
 // Exercise the actual final-KO XP path, with the fixture observing before/after the production event listener.
 probe('stop');await start('inside');await wait(()=>probe().started,'actual NPC battle initialized');probe('recordnatural');
 const startingExperience=probe().experience;
 for(let n=0;n<80&&probe().active;n++){probe('play');await pause(300);}
 await wait(()=>!probe().active,'real victory and final XP',30000);s=probe();
 assert.ok(s.naturalBefore>0,'final KO must have a genuine native XP event');
 assert.equal(s.naturalAfter,s.naturalBefore*(guard?2:1));
 assert.equal(s.experience-startingExperience,s.naturalAfter);pass('Real Showdown battle finishes with a final knockout and the native awarded XP matches the regional multiplier');
 assert.deepEqual(s.inventory,inventory);assert.equal(s.op,false);pass('Inventory remains unchanged and player never receives OP');
 fs.writeFileSync(path.join(root,'region-xp-test-result.json'),JSON.stringify({passed:true,guard,scenarios:results.length,realFinalKo:{base:s.naturalBefore,awarded:s.naturalAfter},tcpClients:1,humanClients:0,results},null,2));c.end();
}catch(e){console.error(e.stack);c.end();process.exitCode=1;}})();

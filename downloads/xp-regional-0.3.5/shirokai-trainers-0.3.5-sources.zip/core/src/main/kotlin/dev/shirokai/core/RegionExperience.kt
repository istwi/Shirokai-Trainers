package dev.shirokai.core

import kotlin.math.floor

/** Opt-in per-region bonuses. Guard owns the geometry; this file never grants access/bypass. */
data class RegionExperienceConfig(
    val schemaVersion: Int = 1,
    val enabled: Boolean = true,
    val regions: List<RegionExperienceRule> = emptyList()
) {
    fun validate() {
        require(schemaVersion == 1) { "Versão de xp-regions.json não suportada" }
        require(regions.size <= 128) { "Máximo de 128 regiões de XP" }
        regions.forEach { it.validate() }
        require(regions.map { it.dimension to it.region }.distinct().size == regions.size) { "Região de XP duplicada na dimensão" }
    }
    /** Overlapping configured regions never multiply together; use the highest matching bonus. */
    fun multiplier(trainer: String, dimension: String, containsBoth: (String) -> Boolean): Double =
        if (!enabled) 1.0 else regions.asSequence().filter {
            it.enabled && it.dimension == dimension && (it.trainers.isEmpty() || trainer in it.trainers)
        }.filter { containsBoth(it.region) }.maxOfOrNull { it.multiplier } ?: 1.0
}

data class RegionExperienceRule(
    val region: String = "farm_xp",
    val dimension: String = "minecraft:overworld",
    val multiplier: Double = 2.0,
    val enabled: Boolean = true,
    val trainers: List<String> = emptyList()
) {
    fun validate() {
        require(region.matches(Regex("[a-z0-9_-]{1,64}")) && region != "__global__") { "Informe uma região delimitada do Guard; __global__ não é permitido" }
        require(dimension.matches(Regex("[a-z0-9_.-]+:[a-z0-9_./-]+"))) { "Dimensão de XP inválida" }
        require(multiplier.isFinite() && multiplier in 1.0..10.0) { "Multiplicador de XP: 1.0 a 10.0" }
        require(trainers.size <= 256 && trainers.all(::validId) && trainers.distinct().size == trainers.size) { "IDs de treinadores inválidos ou duplicados" }
    }
}

fun regionExperience(amount: Int, multiplier: Double): Int {
    require(multiplier.isFinite() && multiplier in 1.0..10.0)
    if (amount <= 0) return amount
    return floor(amount.toDouble() * multiplier).coerceAtMost(Int.MAX_VALUE.toDouble()).toInt()
}

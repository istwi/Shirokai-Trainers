package dev.shirokai.core

/** Declarative only: display strings never become MoLang or player-supplied commands. */
data class NpcDialogue(
    val schemaVersion: Int = 1,
    val id: String = "",
    val title: String = "",
    val startPage: String = "inicio",
    val timeoutSeconds: Int = 120,
    val pages: List<NpcDialoguePage> = emptyList()
) {
    fun validate() {
        require(schemaVersion == 1 && validId(id)) { "Versão/ID de diálogo inválido" }
        require(title.length <= 120 && title.none { it.isISOControl() }) { "Título inválido" }
        require(timeoutSeconds in 15..3600) { "Timeout deve estar entre 15 e 3600 segundos" }
        require(pages.size in 1..32) { "Diálogo deve ter 1 a 32 páginas" }
        require(pages.map { it.id }.distinct().size == pages.size) { "Página duplicada" }
        val ids = pages.map { it.id }.toSet()
        require(startPage in ids) { "Página inicial inexistente" }
        pages.forEach { page ->
            page.validate()
            page.buttons.filter { it.action == "page" }.forEach {
                require(it.page in ids) { "Destino de página inexistente: ${it.page}" }
            }
        }
    }
    companion object {
        fun merchant(id: String) = NpcDialogue(id = id, title = "Mercador", pages = listOf(
            NpcDialoguePage("inicio", "Olá, %player%! Como posso ajudar?", buttons = listOf(
                NpcDialogueButton("comprar", "Comprar", "command", command = "zmenu"),
                NpcDialogueButton("sobre", "Informações", "page", page = "informacoes"),
                NpcDialogueButton("sair", "Sair", "close")
            )),
            NpcDialoguePage("informacoes", "A loja abre no Zorykai-menu.\nUse o menu da loja para comprar ou vender.", buttons = listOf(
                NpcDialogueButton("voltar", "Voltar", "page", page = "inicio"),
                NpcDialogueButton("sair", "Sair", "close")
            ))
        ))
        fun battle(id: String) = NpcDialogue(id = id, pages = listOf(
            NpcDialoguePage("inicio", "Olá, %player%! Pronto para um desafio?", buttons = listOf(
                NpcDialogueButton("batalhar", "Batalhar", "battle"),
                NpcDialogueButton("sair", "Agora não", "close")
            ))
        ))
    }
}

data class NpcDialoguePage(
    val id: String = "",
    val text: String = "",
    val vertical: Boolean = false,
    val speaker: String = "npc",
    val buttons: List<NpcDialogueButton> = emptyList()
) {
    fun validate() {
        require(validId(id)) { "ID de página inválido" }
        require(speaker in setOf("npc", "player")) { "Speaker deve ser npc ou player" }
        require(text.isNotBlank() && text.length <= 2000 && text.none { it.isISOControl() && it != '\n' }) { "Texto de página inválido" }
        require(buttons.size in 1..6) { "Cada página deve ter 1 a 6 botões" }
        require(buttons.map { it.id }.distinct().size == buttons.size) { "Botão duplicado" }
        buttons.forEach { it.validate() }
    }
}

data class NpcDialogueButton(
    val id: String = "",
    val label: String = "",
    val action: String = "close",
    val command: String? = null,
    val executor: String = "player",
    val page: String? = null,
    val trainer: String? = null,
    val permission: String? = null
) {
    fun validate() {
        require(validId(id) && label.isNotBlank() && label.length <= 80 && label.none { it.isISOControl() }) { "ID/texto de botão inválido" }
        require(permission == null || permission.matches(Regex("[A-Za-z0-9_.:-]{1,128}"))) { "Permissão de botão inválida" }
        when (action) {
            "command" -> {
                require(command != null && page == null && trainer == null) { "Botão command exige apenas command/executor" }
                NpcClickCommand(executor, command).validate()
            }
            "page" -> require(page != null && validId(page) && command == null && trainer == null && executor == "player") { "Botão page exige apenas page" }
            "battle" -> require(command == null && page == null && (trainer == null || validId(trainer)) && executor == "player") { "Botão battle aceita apenas trainer opcional" }
            "close" -> require(command == null && page == null && trainer == null && executor == "player") { "Botão close não executa ação adicional" }
            else -> error("Ação de botão desconhecida: $action")
        }
    }
}

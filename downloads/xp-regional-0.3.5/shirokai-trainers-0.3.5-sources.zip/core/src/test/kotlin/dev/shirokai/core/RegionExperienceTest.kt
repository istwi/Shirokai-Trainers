package dev.shirokai.core

import com.google.gson.Gson
import org.junit.jupiter.api.Test
import kotlin.test.*

class RegionExperienceTest {
    @Test fun `only matching dimension trainer and shared region receive a bonus`() {
        val config = RegionExperienceConfig(regions = listOf(RegionExperienceRule(trainers = listOf("blissey"))))
        config.validate()
        assertEquals(2.0, config.multiplier("blissey", "minecraft:overworld") { it == "farm_xp" })
        assertEquals(1.0, config.multiplier("other", "minecraft:overworld") { true })
        assertEquals(1.0, config.multiplier("blissey", "minecraft:the_nether") { true })
        assertEquals(1.0, config.multiplier("blissey", "minecraft:overworld") { false })
    }
    @Test fun `overlap selects highest bonus without stacking and disabled rules are ignored`() {
        val rules = listOf(RegionExperienceRule("a", multiplier = 2.0), RegionExperienceRule("b", multiplier = 3.0), RegionExperienceRule("c", multiplier = 10.0, enabled = false))
        assertEquals(3.0, RegionExperienceConfig(regions = rules).multiplier("npc", "minecraft:overworld") { true })
        assertEquals(1.0, RegionExperienceConfig(enabled = false, regions = rules).multiplier("npc", "minecraft:overworld") { error("disabled must not query Guard") })
        assertEquals(1.0, RegionExperienceConfig().multiplier("npc", "minecraft:overworld") { error("empty must not query Guard") })
    }
    @Test fun `invalid multipliers global regions and duplicate rules cannot enable the feature`() {
        for (n in listOf(Double.NaN, Double.POSITIVE_INFINITY, 0.0, -2.0, 10.01))
            assertFailsWith<IllegalArgumentException> { RegionExperienceConfig(regions = listOf(RegionExperienceRule(multiplier = n))).validate() }
        assertFailsWith<IllegalArgumentException> { RegionExperienceRule(region = "__global__").validate() }
        assertFailsWith<IllegalArgumentException> { RegionExperienceRule(dimension = "bad dimension").validate() }
        assertFailsWith<IllegalArgumentException> { RegionExperienceConfig(regions = listOf(RegionExperienceRule(), RegionExperienceRule())).validate() }
        assertFailsWith<IllegalArgumentException> { RegionExperienceRule(trainers = listOf("bad id")).validate() }
        assertFailsWith<IllegalArgumentException> { RegionExperienceConfig(schemaVersion = 2).validate() }
    }
    @Test fun `native integer XP rounding cannot overflow or create XP from zero`() {
        assertEquals(200, regionExperience(100, 2.0))
        assertEquals(151, regionExperience(101, 1.5))
        assertEquals(0, regionExperience(0, 10.0))
        assertEquals(-1, regionExperience(-1, 2.0))
        assertEquals(Int.MAX_VALUE, regionExperience(Int.MAX_VALUE, 10.0))
        assertEquals(101, regionExperience(101, 1.0))
    }
    @Test fun `configuration round trips and previous snapshot does not change after reload`() {
        val before = RegionExperienceConfig(regions = listOf(RegionExperienceRule(multiplier = 2.0)))
        val multiplier = before.multiplier("npc", "minecraft:overworld") { true }
        val after = Gson().fromJson("""{"schemaVersion":1,"enabled":true,"regions":[{"region":"farm_xp","dimension":"minecraft:overworld","multiplier":3.0,"enabled":true,"trainers":[]}]}""", RegionExperienceConfig::class.java)
        after.validate()
        assertEquals(before, Gson().fromJson(Gson().toJson(before), RegionExperienceConfig::class.java))
        assertEquals(200, regionExperience(100, multiplier))
        assertEquals(3.0, after.multiplier("npc", "minecraft:overworld") { true })
    }
}

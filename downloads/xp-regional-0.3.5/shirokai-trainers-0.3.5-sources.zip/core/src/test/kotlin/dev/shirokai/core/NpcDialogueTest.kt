package dev.shirokai.core

import com.google.gson.Gson
import java.nio.file.Files
import java.util.UUID
import kotlin.test.*
import org.junit.jupiter.api.Test

class NpcDialogueTest {
    @Test fun `merchant and battle templates validate with literal actions and reachable pages`() {
        NpcDialogue.merchant("vendedor").validate()
        NpcDialogue.battle("treinador").validate()
        val dialogue = NpcDialogue.merchant("shop")
        assertEquals(listOf("command", "page", "close"), dialogue.pages.first().buttons.map { it.action })
        assertEquals("player", dialogue.pages.first().buttons.first().executor)
    }
    @Test fun `dialogue and binding survive save without changing trainer player or identity`() {
        val root = Files.createTempDirectory("npc-dialogue")
        val store = JsonStore(root)
        val trainer = Trainer("blue"); val player = PlayerProgress(UUID.randomUUID())
        store.saveTrainer(trainer); store.savePlayer(player)
        val beforeTrainer = Files.readAllBytes(store.trainerPath("blue"))
        val beforePlayer = Files.readAllBytes(store.playerPath(player.uuid))
        val npc = TrainerNpc("blue_npc", UUID.randomUUID(), true, "blue", "minecraft:overworld", 0.0, 64.0, 0.0, dialogue = "welcome")
        val registry = NpcRegistry(npcs = listOf(npc)); registry.validate()
        store.write(root.resolve("npcs.json"), registry)
        assertEquals(npc, store.read(root.resolve("npcs.json"), NpcRegistry::class.java) { it.validate() }!!.npcs.single())
        val dialogue = NpcDialogue.merchant("welcome")
        store.write(root.resolve("dialogues/welcome.json"), dialogue)
        assertEquals(dialogue, store.read(root.resolve("dialogues/welcome.json"), NpcDialogue::class.java) { it.validate() })
        assertContentEquals(beforeTrainer, Files.readAllBytes(store.trainerPath("blue")))
        assertContentEquals(beforePlayer, Files.readAllBytes(store.playerPath(player.uuid)))
    }
    @Test fun `old NPC registry keeps its direct command when no dialogue is configured`() {
        val json = """{"id":"old","entity":"${UUID.randomUUID()}","owned":true,"trainer":null,"dimension":"minecraft:overworld","x":0,"y":64,"z":0,"message":"Oi","confirmation":"Sim","confirm":true,"clickCommand":{"executor":"player","command":"shop"}}"""
        val npc = Gson().fromJson(json, TrainerNpc::class.java)
        npc.validate(); assertNull(npc.dialogue); assertEquals("shop", npc.clickCommand!!.command)
        npc.copy(dialogue = "vendedor").validate()
        assertFails { npc.copy(dialogue = "../escape").validate() }
    }
    @Test fun `reject duplicate pages buttons missing targets control codes and excessive content`() {
        val base = NpcDialogue.merchant("valid")
        for (invalid in listOf(
            base.copy(id = "../bad"), base.copy(schemaVersion = 2), base.copy(timeoutSeconds = 0),
            base.copy(pages = emptyList()), base.copy(startPage = "missing"),
            base.copy(pages = base.pages + base.pages.first()),
            base.copy(pages = List(33) { base.pages.first().copy(id = "p$it") }),
            base.copy(title = "x\nstop"),
            base.copy(pages = listOf(base.pages.first().copy(speaker = "console"))),
            base.copy(pages = listOf(NpcDialoguePage("inicio", "x", buttons = emptyList()))),
            base.copy(pages = listOf(NpcDialoguePage("inicio", "x\u0000y", buttons = listOf(NpcDialogueButton("sair", "Sair"))))),
            base.copy(pages = listOf(NpcDialoguePage("inicio", "x", buttons = List(7) { NpcDialogueButton("b$it", "Sair") }))),
            base.copy(pages = listOf(NpcDialoguePage("inicio", "x", buttons = List(2) { NpcDialogueButton("same", "Sair") }))),
            base.copy(pages = listOf(NpcDialoguePage("inicio", "x", buttons = listOf(NpcDialogueButton("next", "Next", "page", page = "missing")))))
        )) assertFails("Accepted invalid dialogue $invalid") { invalid.validate() }
    }
    @Test fun `button actions cannot smuggle commands executors targets or placeholders`() {
        for (button in listOf(
            NpcDialogueButton("x", "X", "unknown"),
            NpcDialogueButton("x", "X", "close", command = "stop"),
            NpcDialogueButton("x", "X", "battle", executor = "console"),
            NpcDialogueButton("x", "X", "page", page = "next", command = "stop"),
            NpcDialogueButton("x", "X", "command", command = "/shop"),
            NpcDialogueButton("x", "X", "command", command = "shop\nstop"),
            NpcDialogueButton("x", "X", "command", command = "say %trainer_id%"),
            NpcDialogueButton("x", "X", "command", command = "shop prefix%player%"),
            NpcDialogueButton("x", "X", "command", command = "shop", executor = "op"),
            NpcDialogueButton("x", "X", "battle", trainer = "../bad"),
            NpcDialogueButton("x", "X", permission = "vip\nadmin")
        )) assertFails("Accepted unsafe $button") { button.validate() }
        NpcDialogueButton("x", "Loja VIP", "command", command = "shop %player%", executor = "console", permission = "shop.vip").validate()
    }
}

package dev.shirokai.fabric

import dev.shirokai.core.*
import net.minecraft.core.component.DataComponents
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.SimpleContainer
import net.minecraft.world.SimpleMenuProvider
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.entity.player.Player
import net.minecraft.world.inventory.ChestMenu
import net.minecraft.world.inventory.ClickType
import net.minecraft.world.inventory.MenuType
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import com.cobblemon.mod.common.api.pokemon.PokemonSpecies
import com.cobblemon.mod.common.api.pokemon.Natures
import com.cobblemon.mod.common.api.moves.Moves
import net.minecraft.core.registries.BuiltInRegistries

/** Vanilla chest screens; no client code or custom packets. All clicks are consumed. */
class TrainerMenus(private val mod: ShirokaiTrainers) {
    private fun choose(player: ServerPlayer, title: String, entries: List<Pair<String, String>>, back: () -> Unit, select: (String) -> Unit, page: Int = 0) {
        val buttons = entries.drop(page * 45).take(45).mapIndexed { index, entry ->
            index to Button(Items.PAPER, entry.second) { select(entry.first) }
        }.toMap().toMutableMap()
        if (page > 0) buttons[45] = Button(Items.ARROW, "Anterior") { choose(player, title, entries, back, select, page - 1) }
        buttons[49] = Button(Items.BARRIER, "Voltar") { back() }
        if (entries.size > (page + 1) * 45) buttons[53] = Button(Items.ARROW, "Próxima") { choose(player, title, entries, back, select, page + 1) }
        open(player, title, buttons, true)
    }
    private data class Button(val item: Item, val title: String, val click: (Int) -> Unit)
    private fun open(player: ServerPlayer, title: String, buttons: Map<Int, Button>, administrative: Boolean) {
        val inventory = SimpleContainer(54)
        buttons.forEach { (slot, button) -> inventory.setItem(slot, ItemStack(button.item).also {
            it.set(DataComponents.CUSTOM_NAME, Component.literal(button.title))
        }) }
        player.openMenu(SimpleMenuProvider({ id, inv, _ -> object : ChestMenu(MenuType.GENERIC_9x6, id, inv, inventory, 6) {
            override fun stillValid(p: Player) = !administrative || mod.admin(player.createCommandSourceStack())
            override fun quickMoveStack(p: Player, slot: Int): ItemStack = ItemStack.EMPTY
            override fun clicked(slot: Int, button: Int, type: ClickType, p: Player) {
                if (p.uuid != player.uuid || (administrative && !mod.admin(player.createCommandSourceStack()))) { player.closeContainer(); return }
                if (type != ClickType.PICKUP || button !in 0..1) return
                try { buttons[slot]?.click?.invoke(button) } catch (e: Exception) {
                    player.sendSystemMessage(Component.literal("§c${e.message}"))
                    if (mod.debug) mod.log.error("Falha em menu", e)
                }
                broadcastChanges()
            }
        } }, Component.literal(title)))
    }
    fun list(player: ServerPlayer, admin: Boolean = false, page: Int = 0) {
        val trainers = mod.trainers.values.sortedBy { it.id }
        val buttons = mutableMapOf<Int, Button>()
        trainers.drop(page * 45).take(45).forEachIndexed { i, t ->
            buttons[i] = Button(Items.PLAYER_HEAD, t.name) { if (admin) trainer(player, t) else difficulties(player, t) }
        }
        if (page > 0) buttons[45] = Button(Items.ARROW, "Anterior") { list(player, admin, page - 1) }
        if (trainers.size > (page + 1) * 45) buttons[53] = Button(Items.ARROW, "Próxima") { list(player, admin, page + 1) }
        if (admin) buttons[49] = Button(Items.WRITABLE_BOOK, "Criar: /traineradmin create <id>") {
            player.closeContainer(); player.sendSystemMessage(Component.literal("/traineradmin create <id>"))
        }
        if (admin) buttons[48] = Button(Items.ARMOR_STAND, "NPCs Cobblemon") { npcs(player) }
        open(player, if (admin) "Administrar treinadores" else "Desafiar treinador", buttons, admin)
    }
    fun npcChallenge(player: ServerPlayer, npc: dev.shirokai.core.TrainerNpc) {
        open(player, npc.confirmation, mapOf(
            20 to Button(Items.IRON_SWORD, npc.confirmation) {
                player.closeContainer()
                mod.npcs.challenge(player, npc.id, npc.entity)
            },
            24 to Button(Items.BARRIER, "Cancelar") { player.closeContainer() }
        ), false)
    }
    fun npcs(player: ServerPlayer, page: Int = 0) {
        require(mod.admin(player.createCommandSourceStack()))
        val entries = mod.npcs.records.values.filterNot { it.removed }.sortedBy { it.id }
        val buttons = entries.drop(page * 45).take(45).mapIndexed { i, r ->
            i to Button(Items.PLAYER_HEAD, "${r.id} → ${r.dialogue?.let { "diálogo: $it" } ?: r.trainer ?: if (r.clickCommand != null) "comando" else "sem treinador"}") { npcAdmin(player, r.id) }
        }.toMap().toMutableMap()
        if (page > 0) buttons[45] = Button(Items.ARROW, "Anterior") { npcs(player, page - 1) }
        if (entries.size > (page + 1) * 45) buttons[53] = Button(Items.ARROW, "Próxima") { npcs(player, page + 1) }
        buttons[46] = Button(Items.ARMOR_STAND, "Criar NPC na minha posição") {
            player.closeContainer()
            player.sendSystemMessage(Component.literal("/traineradmin npc create <npc> <treinador>"))
        }
        buttons[47] = Button(Items.LEAD, "Vincular NPC existente por clique") {
            player.closeContainer()
            player.sendSystemMessage(Component.literal("/traineradmin npc select <novo_id_npc> <treinador> — depois clique no NPC (60s)"))
        }
        buttons[48] = Button(Items.SHEARS, "Desvincular por clique") {
            player.closeContainer(); mod.npcs.command(player.createCommandSourceStack(), "unselect")
        }
        buttons[49] = Button(Items.ARROW, "Voltar") { list(player, true) }
        buttons[51] = Button(Items.COMMAND_BLOCK, "Criar NPC de comandos, sem treinador") {
            player.closeContainer()
            player.sendSystemMessage(Component.literal("/traineradmin npc create-command <npc>"))
        }
        buttons[50] = Button(Items.BOOK, "Comandos e ajuda") { player.sendSystemMessage(Component.literal(TrainerNpcs.HELP)) }
        open(player, "NPCs Cobblemon", buttons, true)
    }
    private fun npcAdmin(player: ServerPlayer, id: String) {
        require(mod.admin(player.createCommandSourceStack()))
        val r = mod.npcs.records[id]?.takeUnless { it.removed } ?: error("NPC removido")
        fun run(args: String) { mod.npcs.command(player.createCommandSourceStack(), args) }
        fun hint(action: String, syntax: String) {
            player.closeContainer()
            player.sendSystemMessage(Component.literal("/traineradmin npc $action $id $syntax"))
        }
        val buttons = mutableMapOf(
            0 to Button(Items.PAPER, "Consultar UUID, mundo e aparência") { run("show $id") },
            1 to Button(Items.NAME_TAG, "Editar nome") { hint("name", "<nome>") },
            2 to Button(Items.PLAYER_HEAD, "Aparência: classe") { run("classes"); hint("class", "<namespace:classe>") },
            3 to Button(Items.PAINTING, "Aparência: recurso") { hint("resource", "<namespace:recurso|default>") },
            4 to Button(Items.LEATHER, "Aparência: skin PNG local") { hint("skin", "<arquivo.png> default|slim") },
            6 to Button(Items.PLAYER_HEAD, "Skin pelo nick Minecraft") { hint("skin", "player <nick>") },
            7 to Button(Items.PAINTING, "Skin por URL de PNG") { hint("skin", "url <https://imagem.png> [default|slim]") },
            8 to Button(Items.BARRIER, "Remover skin personalizada") { run("skin $id clear") },
            5 to Button(Items.DIAMOND, "Aparência: aspectos") { hint("aspects", "<aspecto1,aspecto2|clear>") },
            9 to Button(Items.COMPASS, "Mover para minha posição e mundo") { run("move $id") },
            10 to Button(Items.CLOCK, "Girar") { hint("rotate", "<yaw> [pitch]") },
            11 to Button(Items.ANVIL, "Parar movimentação") { run("stationary $id true") },
            12 to Button(Items.FEATHER, "Permitir movimentação nativa") { run("stationary $id false") },
            18 to Button(Items.BOOK, "Mensagem de interação") { hint("message", "<mensagem>") },
            19 to Button(Items.WRITABLE_BOOK, "Texto de confirmação") { hint("confirmation", "<texto>") },
            20 to Button(Items.LIME_DYE, "Confirmação: ${r.confirm}") { run("confirm $id ${!r.confirm}"); npcAdmin(player, id) },
            27 to Button(Items.IRON_SWORD, "Treinador: ${r.trainer ?: "nenhum"}") {
                choose(player, "Vincular treinador", mod.trainers.values.sortedBy { it.id }.map { it.id to it.name },
                    { npcAdmin(player, id) }, { run("link $id $it"); npcAdmin(player, id) })
            },
            28 to Button(Items.SHEARS, "Desvincular, preservando entidade") { run("unlink $id"); npcs(player) },
            49 to Button(Items.ARROW, "Voltar") { npcs(player) }
        )
        buttons[21] = Button(Items.WRITTEN_BOOK, "Diálogo Cobblemon: ${r.dialogue ?: "desativado"}") {
            choose(player, "Selecionar diálogo", mod.npcs.dialogues.definitions.keys.sorted().map { it to it },
                { npcAdmin(player, id) }, { run("dialogue $id $it"); npcAdmin(player, id) })
        }
        buttons[22] = Button(Items.BARRIER, "Desativar diálogo e restaurar clique anterior") {
            run("dialogue $id off"); npcAdmin(player, id)
        }
        if (r.dialogue != null) buttons[23] = Button(Items.ENDER_EYE, "Testar diálogo (perto do NPC)") {
            run("dialogue-preview $id")
        }
        if (r.trainer == null) {
            listOf(18, 19, 20).forEach { buttons.remove(it) }
            buttons[30] = Button(Items.COMMAND_BLOCK, "Comando: ${r.clickCommand?.executor ?: "nenhum"}") {
                hint("command", "player|console <comando sem />; placeholders: %player%, %player_uuid%")
            }
            buttons[31] = Button(Items.BARRIER, "Remover comando de clique") { run("clear-command $id"); npcAdmin(player, id) }
        }
        if (r.owned) buttons[35] = Button(Items.BARRIER, "Remover NPC próprio") {
            open(player, "Remover NPC $id?", mapOf(
                20 to Button(Items.RED_DYE, "Confirmar remoção (treinador e progresso preservados)") { run("remove $id"); npcs(player) },
                24 to Button(Items.ARROW, "Cancelar") { npcAdmin(player, id) }
            ), true)
        }
        open(player, "NPC $id", buttons, true)
    }
    private fun difficulties(player: ServerPlayer, trainer: Trainer, page: Int = 0) {
        val buttons = trainer.difficulties.drop(page * 45).take(45).mapIndexed { i, d -> i to Button(Items.IRON_SWORD, d.id) {
            player.closeContainer(); mod.challenge(player, trainer.id, d.id)
        } }.toMap().toMutableMap()
        if (page > 0) buttons[45] = Button(Items.ARROW, "Anterior") { difficulties(player, trainer, page - 1) }
        if (trainer.difficulties.size > (page + 1) * 45) buttons[53] = Button(Items.ARROW, "Próxima") { difficulties(player, trainer, page + 1) }
        buttons[49] = Button(Items.BARRIER, "Voltar") { list(player) }
        open(player, trainer.name, buttons, false)
    }
    fun trainer(player: ServerPlayer, old: Trainer, difficulty: String = old.difficulties.first().id) {
        val t = mod.trainers[old.id] ?: error("Treinador removido")
        val d = t.difficulties.first { it.id == difficulty }
        val buttons = mutableMapOf<Int, Button>()
        d.team.forEachIndexed { i, p -> buttons[10 + i] = Button(Items.EGG, "${i + 1}. ${p.species} Nv.${p.level}") { pokemon(player, t, d, i) } }
        fun save(updated: Trainer) {
            require(mod.trainers[t.id] == t) { "Treinador alterado por outro administrador; reabra o menu" }
            mod.save(updated, player.scoreboardName); trainer(player, updated, difficulty)
        }
        if (d.team.size < 6) buttons[16] = Button(Items.EMERALD, "Adicionar Pokémon") {
            save(t.copy(difficulties = t.difficulties.map { if (it.id == d.id) it.copy(team = it.team + PokemonSpec()) else it }))
        }
        buttons[28] = Button(Items.CLOCK, "Cooldown: ${formatDuration(d.cooldownSeconds)} (±30s)") { button ->
            save(t.copy(difficulties = t.difficulties.map { if (it.id == d.id) it.copy(cooldownSeconds = (d.cooldownSeconds + if (button == 0) 30 else -30).coerceIn(0, 315360000)) else it }))
        }
        buttons[29] = Button(Items.COMPARATOR, "Simultâneas: ${t.simultaneous}") { save(t.copy(simultaneous = !t.simultaneous)) }
        buttons[30] = Button(Items.REDSTONE_TORCH, "Ativo: ${t.enabled}") { save(t.copy(enabled = !t.enabled)) }
        buttons[31] = Button(Items.GOLD_INGOT, "Ginásio: ${t.gym}") { save(t.copy(gym = !t.gym)) }
        buttons[32] = Button(Items.REPEATER, "Dificuldade automática: ${t.automaticDifficulty}") { save(t.copy(automaticDifficulty = !t.automaticDifficulty)) }
        buttons[33] = Button(Items.BOOK, "Dificuldade: ${d.id} (clicar para alternar)") {
            trainer(player, t, t.difficulties[(t.difficulties.indexOf(d) + 1) % t.difficulties.size].id)
        }
        buttons[34] = Button(Items.ENDER_EYE, "IA: ${d.skill} (±1)") { button ->
            save(t.copy(difficulties = t.difficulties.map { if (it.id == d.id) it.copy(skill = (d.skill + if (button == 0) 1 else -1).coerceIn(0, 5)) else it }))
        }
        buttons[40] = Button(Items.WRITABLE_BOOK, "Texto, recompensas, requisitos: comandos administrativos") {
            player.closeContainer(); player.sendSystemMessage(Component.literal(TrainerCommands.HELP))
        }
        buttons[49] = Button(Items.BARRIER, "Voltar") { list(player, true) }
        open(player, "${t.name} / ${d.id}", buttons, true)
    }
    private fun pokemon(player: ServerPlayer, old: Trainer, previous: Difficulty, index: Int) {
        val t = mod.trainers.getValue(old.id)
        val d = t.difficulties.first { it.id == previous.id }
        val p = d.team.getOrNull(index) ?: error("Pokémon removido")
        val buttons = mutableMapOf<Int, Button>()
        fun save(spec: PokemonSpec?) {
            require(mod.trainers[t.id] == t) { "Treinador alterado por outro administrador; reabra o menu" }
            val team = d.team.toMutableList()
            if (spec == null) team.removeAt(index) else team[index] = spec
            val updated = t.copy(difficulties = t.difficulties.map { if (it.id == d.id) it.copy(team = team) else it })
            mod.save(updated, player.scoreboardName)
            if (spec == null) trainer(player, updated, d.id) else pokemon(player, updated, d, index)
        }
        buttons[4] = Button(Items.EGG, "Espécie: ${p.species}") {
            choose(player, "Escolher espécie", PokemonSpecies.implemented.sortedBy { it.name }.map { it.resourceIdentifier.toString() to it.name },
                { pokemon(player, t, d, index) }, { save(p.copy(species = it, form = null, ability = null)) })
        }
        buttons[5] = Button(Items.ENDER_PEARL, "Forma: ${p.form ?: "padrão"}") {
            val species = PokemonAdapter.species(p)
            choose(player, "Escolher forma", listOf("" to "Padrão") + species.forms.map { it.name to it.name },
                { pokemon(player, t, d, index) }, { save(p.copy(form = it.takeIf(String::isNotBlank), ability = null)) })
        }
        buttons[10] = Button(Items.EXPERIENCE_BOTTLE, "Nível ${p.level} (±1)") { save(p.copy(level = (p.level + if (it == 0) 1 else -1).coerceIn(1, 100))) }
        buttons[11] = Button(Items.NETHER_STAR, "Shiny: ${p.shiny}") { save(p.copy(shiny = !p.shiny)) }
        PokemonSpec.STATS.forEachIndexed { i, stat ->
            buttons[19 + i] = Button(Items.IRON_INGOT, "IV $stat: ${p.ivs[stat] ?: 31} (±1)") { button ->
                save(p.copy(ivs = p.ivs + (stat to ((p.ivs[stat] ?: 31) + if (button == 0) 1 else -1).coerceIn(0, 31))))
            }
            buttons[28 + i] = Button(Items.GOLD_INGOT, "EV $stat: ${p.evs[stat] ?: 0} (±1)") { button ->
                save(p.copy(evs = p.evs + (stat to ((p.evs[stat] ?: 0) + if (button == 0) 1 else -1).coerceIn(0, 252))))
            }
        }
        buttons[12] = Button(Items.BOOK, "Nature: ${p.nature}") {
            choose(player, "Nature", Natures.all().map { it.name.path to it.name.path }.sortedBy { it.first },
                { pokemon(player, t, d, index) }, { save(p.copy(nature = it)) })
        }
        buttons[13] = Button(Items.BLAZE_POWDER, "Ability: ${p.ability ?: "automática"}") {
            val species = PokemonAdapter.species(p)
            val form = p.form?.let { name -> species.forms.firstOrNull { it.name.equals(name, true) } } ?: species.standardForm
            choose(player, "Ability", listOf("" to "Automática") + form.abilities.map { it.template.name to it.template.name }.distinct(),
                { pokemon(player, t, d, index) }, { save(p.copy(ability = it.takeIf(String::isNotBlank))) })
        }
        buttons[14] = Button(Items.CHEST, "Item: ${p.heldItem ?: "nenhum"}") {
            choose(player, "Item equipado", listOf("" to "Nenhum") + BuiltInRegistries.ITEM.keySet().filter { it.path != "air" }.sortedBy { it.toString() }.map { it.toString() to it.toString() },
                { pokemon(player, t, d, index) }, { save(p.copy(heldItem = it.takeIf(String::isNotBlank))) })
        }
        for (moveSlot in 0..3) buttons[37 + moveSlot] = Button(Items.IRON_SWORD, "Movimento ${moveSlot + 1}: ${p.moves.getOrNull(moveSlot) ?: "vazio"}") {
            choose(player, "Movimento ${moveSlot + 1}", listOf("" to "Remover") + Moves.names().sorted().map { it to it },
                { pokemon(player, t, d, index) }, { selected ->
                    val moves = p.moves.toMutableList()
                    if (selected.isBlank()) {
                        require(moveSlot in moves.indices && moves.size > 1) { "Mantenha ao menos um movimento" }; moves.removeAt(moveSlot)
                    } else if (moveSlot in moves.indices) moves[moveSlot] = selected else moves.add(selected)
                    save(p.copy(moves = moves))
                })
        }
        buttons[46] = Button(Items.PAPER, "Copiar para outra equipe") {
            val choices = mod.trainers.values.flatMap { trainer -> trainer.difficulties.filter { it.team.size < 6 }.map { "${trainer.id}/${it.id}" to "${trainer.name} / ${it.id}" } }
            choose(player, "Copiar Pokémon", choices, { pokemon(player, t, d, index) }, { selected ->
                val (id, difficulty) = selected.split('/')
                val destination = mod.trainers.getValue(id)
                mod.save(destination.copy(difficulties = destination.difficulties.map {
                    if (it.id == difficulty) it.copy(team = it.team + p.copy(ivs = p.ivs.toMap(), evs = p.evs.toMap(), moves = p.moves.toList())) else it
                }), player.scoreboardName)
                trainer(player, mod.trainers.getValue(t.id), d.id)
            })
        }
        buttons[43] = Button(Items.BARRIER, "Remover Pokémon") { save(null) }
        buttons[49] = Button(Items.ARROW, "Voltar") { trainer(player, t, d.id) }
        open(player, "Pokémon ${index + 1} — ${d.id}", buttons, true)
    }
}

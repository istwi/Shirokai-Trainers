package dev.shirokai.fabric

import com.cobblemon.mod.common.api.battles.model.PokemonBattle
import com.cobblemon.mod.common.api.events.CobblemonEvents
import com.cobblemon.mod.common.api.pokemon.experience.BattleExperienceSource
import com.cobblemon.mod.common.entity.npc.NPCEntity
import dev.shirokai.core.*
import net.fabricmc.loader.api.FabricLoader
import net.minecraft.server.level.ServerPlayer
import java.lang.reflect.InvocationTargetException
import java.util.Collections
import java.util.UUID
import java.util.WeakHashMap
import kotlin.math.floor

/** Read-only optional bridge: Guard's core types use JDK primitives and survive both mapping namespaces. */
private class GuardRegionBounds {
    private val guard = Class.forName("dev.shirokai.guard.ShiroGuard")
    private val manager = guard.getField("REGIONS").get(null)
    private val get = manager.javaClass.getMethod("get", String::class.java, String::class.java)
    private val bounds = Class.forName("dev.shirokai.guard.core.Region").getMethod("bounds")
    private val contains = Class.forName("dev.shirokai.guard.core.Bounds").getMethod("contains", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
    fun containsBoth(dimension: String, region: String, player: ServerPlayer, npc: NPCEntity): Boolean {
        val record = try { get.invoke(manager, dimension, region) } catch (error: InvocationTargetException) {
            if (error.cause is IllegalArgumentException) return false // Region absent/deleted: no bonus.
            throw error
        }
        val box = bounds.invoke(record) ?: return false // Global regions cannot enable a map-wide bonus.
        fun inside(x: Double, y: Double, z: Double) = contains.invoke(box, floor(x).toInt(), floor(y).toInt(), floor(z).toInt()) == true
        return inside(player.x, player.y, player.z) && inside(npc.x, npc.y, npc.z)
    }
}

class GuardRegionExperience(private val mod: ShirokaiTrainers) {
    private val path = mod.store.root.resolve("xp-regions.json")
    var configuration = RegionExperienceConfig(); private set
    private val bridge by lazy { if (FabricLoader.getInstance().isModLoaded("shirokai_guard")) GuardRegionBounds() else null }
    private var warned = false
    // Final native XP can arrive after victory/result callbacks. Keep the snapshot for as long as
    // the actual battle/source remains reachable, with no persistent/player-wide bonus to leak.
    private data class Bonus(val owner: UUID, val multiplier: Double)
    private val battles = Collections.synchronizedMap(WeakHashMap<PokemonBattle, Bonus>())

    fun read(): RegionExperienceConfig {
        if (!java.nio.file.Files.exists(path)) mod.store.write(path, RegionExperienceConfig())
        return requireNotNull(mod.store.read(path, RegionExperienceConfig::class.java) { it.validate() })
    }
    fun install(next: RegionExperienceConfig) { configuration = next }

    fun snapshot(player: ServerPlayer, npc: NPCEntity?, trainer: String): Double {
        if (npc == null || !player.isAlive || !npc.isAlive || npc.isRemoved || npc.level() !== player.serverLevel()) return 1.0
        return try {
            val lookup = bridge ?: return 1.0
            configuration.multiplier(trainer, player.serverLevel().dimension().location().toString()) { region ->
                lookup.containsBoth(player.serverLevel().dimension().location().toString(), region, player, npc)
            }
        } catch (error: Exception) {
            if (!warned) { warned = true; mod.log.warn("Integração de regiões XP indisponível; mantendo XP normal", error) }
            1.0
        }
    }
    fun track(battle: PokemonBattle, player: UUID, multiplier: Double) {
        if (multiplier > 1.0) battles[battle] = Bonus(player, multiplier)
    }
    fun register() {
        CobblemonEvents.EXPERIENCE_GAINED_EVENT_PRE.subscribe { event ->
            val source = event.source as? BattleExperienceSource ?: return@subscribe
            val bonus = battles[source.battle] ?: return@subscribe
            if (!event.isCanceled && event.pokemon.getOwnerUUID() == bonus.owner)
                event.experience = regionExperience(event.experience, bonus.multiplier)
        }
    }
}

package dev.shirokai.dialoguetest

import com.cobblemon.mod.common.Cobblemon
import com.cobblemon.mod.common.api.battles.model.PokemonBattle
import com.cobblemon.mod.common.api.events.CobblemonEvents
import com.cobblemon.mod.common.api.pokemon.PokemonProperties
import com.cobblemon.mod.common.api.pokemon.experience.*
import com.cobblemon.mod.common.battles.BattleRegistry
import com.cobblemon.mod.common.battles.MoveActionResponse
import com.cobblemon.mod.common.entity.npc.NPCEntity
import com.mojang.brigadier.arguments.StringArgumentType
import dev.shirokai.core.*
import dev.shirokai.fabric.ShirokaiTrainers
import net.fabricmc.api.ModInitializer
import net.fabricmc.loader.api.FabricLoader
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.minecraft.commands.Commands.*
import net.minecraft.core.BlockPos
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.item.ItemStack
import net.minecraft.world.level.block.Blocks
import java.nio.file.Files
import java.nio.file.Path

/** Console-only disposable regression fixture. Not included in production. */
class RegionXpProbe : ModInitializer {
    private val guard = FabricLoader.getInstance().isModLoaded("shirokai_guard")
    private fun mod() = FabricLoader.getInstance().getEntrypoints("main", ModInitializer::class.java).filterIsInstance<ShirokaiTrainers>().single()
    private var lastBattle: PokemonBattle? = null
    private var before = 0
    private var naturalBefore = 0
    private var naturalAfter = 0
    private var result = linkedMapOf<String, Any?>()
    override fun onInitialize() {
        check(java.lang.Boolean.getBoolean("zorykai.dialogueTest"))
        CobblemonEvents.EXPERIENCE_GAINED_EVENT_PRE.subscribe(com.cobblemon.mod.common.api.Priority.HIGHEST) { e -> if (e.source is BattleExperienceSource) naturalBefore = e.experience }
        CobblemonEvents.EXPERIENCE_GAINED_EVENT_POST.subscribe { e -> if (e.source is BattleExperienceSource) naturalAfter = e.experience }
        CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
            dispatcher.register(literal("regionxpprobe").requires { it.entity == null && it.hasPermission(4) }
                .then(argument("action", StringArgumentType.word()).then(argument("player", StringArgumentType.word()).executes { ctx ->
                    val p = ctx.source.server.playerList.getPlayerByName(StringArgumentType.getString(ctx, "player")) ?: error("Offline test player")
                    try { action(p, StringArgumentType.getString(ctx, "action")) }
                    catch (e: Exception) { result = linkedMapOf("error" to e.stackTraceToString()); write(p) }
                    1
                })))
        }
    }
    private fun region(id: String, minX: Int = -4, maxX: Int = 8) {
        if (!guard) return
        val boundsType = Class.forName("dev.shirokai.guard.core.Bounds")
        val box = boundsType.constructors.single().newInstance(minX,190,-4,maxX,210,4)
        val regionType = Class.forName("dev.shirokai.guard.core.Region")
        val region = regionType.getMethod("create",String::class.java,String::class.java,boundsType).invoke(null,id,"minecraft:overworld",box)
        val manager = Class.forName("dev.shirokai.guard.ShiroGuard").getField("REGIONS").get(null)
        manager.javaClass.getMethod("put",regionType).invoke(manager,region)
    }
    private fun removeRegion(id: String) {
        if (!guard) return
        val manager = Class.forName("dev.shirokai.guard.ShiroGuard").getField("REGIONS").get(null)
        manager.javaClass.getMethod("remove",String::class.java,String::class.java).invoke(manager,"minecraft:overworld",id)
    }
    private fun configure(multiplier: Double = 2.0, enabled: Boolean = true, rules: List<RegionExperienceRule>? = null) {
        val m = mod()
        m.store.write(m.store.root.resolve("xp-regions.json"), RegionExperienceConfig(enabled = enabled,regions = rules ?: listOf(RegionExperienceRule(multiplier = multiplier))))
        m.reload()
    }
    private fun npc(p: ServerPlayer) = p.serverLevel().getEntity(mod().npcs.records.getValue("xp_test").entity) as NPCEntity
    private fun start(p: ServerPlayer, remote: Boolean = false) {
        check(BattleRegistry.getBattleByParticipatingPlayer(p) == null)
        if (remote) mod().challenge(p,"xp_farm",null) else mod().npcs.dialogueBattle(p,"xp_test",npc(p).uuid,null)
        lastBattle = requireNotNull(BattleRegistry.getBattleByParticipatingPlayer(p))
    }
    private fun stop(p: ServerPlayer) {
        BattleRegistry.getBattleByParticipatingPlayer(p)?.let { battle -> mod().finish(battle.battleId,Outcome.ABORTED); battle.end() }
    }
    private fun gain(p: ServerPlayer, source: ExperienceSource) {
        val pokemon = Cobblemon.storage.getParty(p).toList().first()
        before = pokemon.experience
        pokemon.addExperienceWithPlayer(p,source,100)
        result["delta"] = pokemon.experience-before
    }
    private fun action(p: ServerPlayer, action: String) {
        result = linkedMapOf()
        when(action) {
            "seed" -> {
                for(x in -8..18) for(z in -6..6) p.serverLevel().setBlock(BlockPos(x,199,z),Blocks.STONE.defaultBlockState(),3)
                p.teleportTo(p.serverLevel(),.5,200.0,.5,setOf(),0f,0f)
                val trainer = Trainer("xp_farm",difficulties=listOf(Difficulty(cooldownSeconds=0,team=listOf(PokemonSpec(species="magikarp",level=5,moves=listOf("splash"))))))
                mod().save(trainer,"region-xp-fixture")
                mod().npcs.command(p.createCommandSourceStack().withPermission(4),"create xp_test xp_farm")
                npc(p).moveTo(4.5,200.0,.5)
                Cobblemon.storage.getParty(p).add(PokemonProperties.parse("dragonite level=70 moves=dragonclaw").create())
                region("farm_xp"); configure()
            }
            "inside" -> { stop(p); p.teleportTo(p.serverLevel(),.5,200.0,.5,setOf(),0f,0f);npc(p).moveTo(4.5,200.0,.5);configure();start(p) }
            "oneoutside" -> { stop(p);p.teleportTo(p.serverLevel(),7.5,200.0,.5,setOf(),0f,0f);npc(p).moveTo(9.5,200.0,.5);configure();start(p) }
            "bothoutside" -> { stop(p);p.teleportTo(p.serverLevel(),10.5,200.0,.5,setOf(),0f,0f);npc(p).moveTo(12.5,200.0,.5);configure();start(p) }
            "remote" -> { stop(p);p.teleportTo(p.serverLevel(),.5,200.0,.5,setOf(),0f,0f);npc(p).moveTo(4.5,200.0,.5);configure();start(p,true) }
            "wrongdimension" -> { stop(p);configure(rules=listOf(RegionExperienceRule(dimension="minecraft:the_nether")));start(p) }
            "wrongtrainer" -> { stop(p);configure(rules=listOf(RegionExperienceRule(trainers=listOf("other_trainer"))));start(p) }
            "disabled" -> { stop(p);configure(enabled=false);start(p) }
            "missingregion" -> { stop(p);configure(rules=listOf(RegionExperienceRule(region="missing")));start(p) }
            "overlap" -> { stop(p);region("xp_extra");configure(rules=listOf(RegionExperienceRule(multiplier=2.0),RegionExperienceRule(region="xp_extra",multiplier=3.0)));start(p) }
            "fractional" -> { stop(p);configure(multiplier=1.5);start(p) }
            "reload3" -> configure(multiplier=3.0)
            "startagain" -> { stop(p);start(p) }
            "boundary" -> { stop(p);p.teleportTo(p.serverLevel(),-.25,200.0,.5,setOf(),0f,0f);npc(p).moveTo(4.5,200.0,.5);region("farm_xp",0,8);configure();start(p) }
            "restorebounds" -> { stop(p);region("farm_xp");p.teleportTo(p.serverLevel(),.5,200.0,.5,setOf(),0f,0f);npc(p).moveTo(4.5,200.0,.5) }
            "battle-xp" -> gain(p,BattleExperienceSource(requireNotNull(lastBattle),emptyList()))
            "command-xp" -> gain(p,CommandExperienceSource(p.createCommandSourceStack()))
            "candy-xp" -> gain(p,CandyExperienceSource(p,ItemStack.EMPTY))
            "foreign-owner" -> {
                val pokemon=PokemonProperties.parse("bulbasaur level=20").create()
                val old=pokemon.experience;pokemon.addExperience(BattleExperienceSource(requireNotNull(lastBattle),emptyList()),100);result["delta"]=pokemon.experience-old
            }
            "delete" -> removeRegion("farm_xp")
            "stop" -> stop(p)
            "play" -> {
                val battle=requireNotNull(lastBattle)
                val actor=battle.actors.first { it.uuid==p.uuid }
                if(actor.mustChoose && actor.request!=null) { actor.setActionResponses(listOf(MoveActionResponse("dragonclaw",battle.actors.first { it.uuid != p.uuid }.activePokemon.first().getPNX(),null))) }
            }
            "recordnatural" -> { naturalBefore=0;naturalAfter=0;before=Cobblemon.storage.getParty(p).toList().first().experience }
            "status" -> Unit
            else -> error("Unknown fixture action")
        }
        write(p)
    }
    private fun write(p: ServerPlayer) {
        val b=BattleRegistry.getBattleByParticipatingPlayer(p)
        result.putAll(mapOf("guard" to guard,"active" to (b!=null),"battleId" to b?.battleId?.toString(),"started" to b?.started,"ended" to lastBattle?.ended,
            "snapshotNow" to mod().regionExperience.snapshot(p,runCatching{npc(p)}.getOrNull(),"xp_farm"),
            "experience" to Cobblemon.storage.getParty(p).toList().firstOrNull()?.experience,"naturalBefore" to naturalBefore,"naturalAfter" to naturalAfter,
            "busy" to Cobblemon.storage.getParty(p).toList().any { it.entity?.isBusy == true },
            "inventory" to p.inventory.items.filterNot{it.isEmpty}.map{it.toString()},"op" to mod().server.playerList.isOp(p.gameProfile)))
        Files.writeString(Path.of("region-xp-probe.json"),mod().gson.toJson(result))
    }
}

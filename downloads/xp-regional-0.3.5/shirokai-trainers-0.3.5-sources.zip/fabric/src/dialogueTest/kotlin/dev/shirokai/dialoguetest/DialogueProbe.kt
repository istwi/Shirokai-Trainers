package dev.shirokai.dialoguetest

import com.cobblemon.mod.common.api.dialogue.*
import com.cobblemon.mod.common.api.dialogue.input.DialogueOptionSetInput
import com.cobblemon.mod.common.api.npc.NPCClasses
import com.cobblemon.mod.common.battles.BattleRegistry
import com.cobblemon.mod.common.api.pokemon.PokemonProperties
import com.cobblemon.mod.common.Cobblemon
import com.cobblemon.mod.common.entity.npc.NPCEntity
import com.mojang.brigadier.arguments.StringArgumentType
import dev.shirokai.core.*
import dev.shirokai.fabric.ShirokaiTrainers
import net.fabricmc.api.ModInitializer
import net.fabricmc.loader.api.FabricLoader
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.minecraft.commands.Commands.*
import net.minecraft.core.BlockPos
import net.minecraft.world.level.block.Blocks
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.InteractionHand
import net.minecraft.world.InteractionResult
import net.fabricmc.fabric.api.event.player.UseEntityCallback
import java.nio.file.Files
import java.nio.file.Path
import java.util.UUID

/** Never included in the release JAR. Fixture commands require console and an isolated-test JVM flag. */
class DialogueProbe : ModInitializer {
    private val marks = mutableMapOf<UUID, Int>()
    private val consoleMarks = mutableMapOf<UUID, Int>()
    private fun mod() = FabricLoader.getInstance().getEntrypoints("main", ModInitializer::class.java).filterIsInstance<ShirokaiTrainers>().single()
    override fun onInitialize() {
        check(java.lang.Boolean.getBoolean("zorykai.dialogueTest")) { "Disposable dialogueTest runtime required" }
        CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
            dispatcher.register(literal("dialogue_marker").executes { ctx ->
                val p = ctx.source.playerOrException
                marks.merge(p.uuid, 1, Int::plus); 1
            })
            dispatcher.register(literal("dialogue_console_marker").requires { it.hasPermission(4) }
                .then(argument("player", StringArgumentType.word()).executes { ctx ->
                    check(ctx.source.entity == null) { "Console executor expected" }
                    val id = UUID.fromString(StringArgumentType.getString(ctx, "player"))
                    consoleMarks.merge(id, 1, Int::plus); 1
                }))
            dispatcher.register(literal("dialogueprobe").requires { it.entity == null && it.hasPermission(4) }
                .then(argument("action", StringArgumentType.word()).then(argument("player", StringArgumentType.word()).executes { ctx ->
                    val p = ctx.source.server.playerList.getPlayerByName(StringArgumentType.getString(ctx, "player")) ?: error("Fixture player offline")
                    probe(p, StringArgumentType.getString(ctx, "action")); 1
                })))
        }
    }
    private fun probe(player: ServerPlayer, action: String) {
        val mod = mod()
        when (action) {
            "seed" -> {
                check(mod.npcs.records["dialogue_test"] == null) { "Fresh test world required" }
                val world = player.serverLevel()
                for (x in -5..8) for (z in -5..5) world.setBlock(BlockPos(x, 199, z), Blocks.STONE.defaultBlockState(), 3)
                player.teleportTo(world, .5, 200.0, .5, setOf(), 0f, 0f)
                val source = player.createCommandSourceStack().withPermission(4)
                mod.npcs.command(source, "create-command dialogue_test")
                mod.npcs.command(source, "name dialogue_test &aMercador Teste")
                mod.npcs.command(source, "command dialogue_test player dialogue_marker")
                mod.npcs.command(source, "create-command legacy_test")
                mod.npcs.command(source, "command legacy_test player dialogue_marker")
                (world.getEntity(mod.npcs.records.getValue("dialogue_test").entity) as NPCEntity).moveTo(2.5, 200.0, .5)
                (world.getEntity(mod.npcs.records.getValue("legacy_test").entity) as NPCEntity).moveTo(-2.5, 200.0, .5)
                val config = NpcDialogue(id = "integration", title = "Mercador %player%", pages = listOf(
                    NpcDialoguePage("inicio", "Olá, %player%! O que procura?", buttons = listOf(
                        NpcDialogueButton("info", "Informações", "page", page = "info"),
                        NpcDialogueButton("loja", "Comprar / Vender", "command", command = "zmenu"),
                        NpcDialogueButton("sair", "Sair", "close")
                    )),
                    NpcDialoguePage("info", "Página de ações", buttons = listOf(
                        NpcDialogueButton("permitido", "Ação com permissão", "command", command = "dialogue_marker", permission = "dialogue.test.allowed"),
                        NpcDialogueButton("console", "Ação de console", "command", command = "dialogue_console_marker %player_uuid%", executor = "console"),
                        NpcDialogueButton("proibido", "Sem OP", "command", command = "op %player%"),
                        NpcDialogueButton("batalhar", "Batalhar", "battle", trainer = "dialogue_battle"),
                        NpcDialogueButton("voltar", "Voltar", "page", page = "inicio")
                    ))
                ))
                config.validate(); mod.store.write(mod.store.root.resolve("dialogues/integration.json"), config)
                mod.npcs.dialogues.reload(); mod.npcs.command(source, "dialogue dialogue_test integration")
                mod.save(Trainer("dialogue_battle", difficulties = listOf(Difficulty(team = listOf(PokemonSpec(species = "magikarp", level = 5, moves = listOf("splash")))))), "dialogue-fixture")
                Cobblemon.storage.getParty(player).add(PokemonProperties.parse("bulbasaur level=20 moves=tackle").create())
            }
            "expire" -> {
                val helper = mod.npcs.dialogues
                val mapField = helper.javaClass.getDeclaredField("sessions").apply { isAccessible = true }
                val session = (mapField.get(helper) as Map<*, *>)[player.uuid] ?: error("No session")
                session.javaClass.getDeclaredField("deadline").apply { isAccessible = true }.setLong(session, 0L)
            }
            "replace" -> DialogueManager.startDialogue(player, Dialogue(pages = listOf(DialoguePage().apply { id = "foreign"; lines = mutableListOf(WrappedDialogueText(net.minecraft.network.chat.Component.literal("Other dialogue"))) })))
            "status" -> Unit
            else -> error("Unknown action")
        }
        val active = DialogueManager.activeDialogues[player.uuid]
        val page = active?.currentPage
        val options = (page?.input as? DialogueOptionSetInput)?.options.orEmpty()
        val result = linkedMapOf<String, Any?>(
            "active" to (active != null), "dialogueId" to active?.dialogueId?.toString(), "inputId" to active?.activeInput?.inputId?.toString(),
            "page" to page?.id, "text" to page?.lines?.joinToString("\n") { it.invoke(active!!).string },
            "buttons" to options.map { mapOf("value" to it.value, "label" to it.text.invoke(active!!).string, "enabled" to it.isSelectable.invoke(active!!)) },
            "speaker" to active?.dialogueReference?.speakers?.get("npc")?.name?.invoke(active)?.string,
            "face" to ((active?.dialogueReference?.speakers?.get("npc")?.face) as? ReferenceDialogueFaceProvider)?.entityId,
            "vertical" to (page?.input as? DialogueOptionSetInput)?.vertical,
            "markers" to (marks[player.uuid] ?: 0), "consoleMarkers" to (consoleMarks[player.uuid] ?: 0),
            "op" to mod.server.playerList.isOp(player.gameProfile),
            "screen" to player.containerMenu.javaClass.name, "screenId" to player.containerMenu.containerId,
            "battle" to (BattleRegistry.getBattleByParticipatingPlayer(player) != null),
            "npcId" to mod.npcs.records["dialogue_test"]?.entity?.let { player.serverLevel().getEntity(it)?.id },
            "legacyId" to mod.npcs.records["legacy_test"]?.entity?.let { player.serverLevel().getEntity(it)?.id },
            "nativePackets" to mapOf("input" to "cobblemon:input_to_dialogue", "escape" to "cobblemon:escape_dialogue")
        )
        Files.writeString(Path.of("dialogue-probe.json"), mod.gson.toJson(result))
    }
}

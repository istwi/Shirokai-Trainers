package dev.shirokai.fabric

import com.cobblemon.mod.common.api.dialogue.*
import com.cobblemon.mod.common.api.dialogue.input.*
import com.cobblemon.mod.common.entity.npc.NPCEntity
import dev.shirokai.core.*
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents
import me.lucko.fabric.api.permissions.v0.Permissions
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer
import java.nio.file.Files
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Cobblemon owns rendering/packets. Only the server chooses configured actions and command sources. */
class NpcDialogues(private val mod: ShirokaiTrainers, private val npcs: TrainerNpcs) {
    private val directory = mod.store.root.resolve("dialogues")
    var definitions: Map<String, NpcDialogue> = emptyMap(); private set
    private class Session(val player: ServerPlayer, val npc: NPCEntity, val binding: TrainerNpc, val definition: NpcDialogue) {
        var active: ActiveDialogue? = null
        var deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(definition.timeoutSeconds.toLong())
        var lastAction = Long.MIN_VALUE / 2
    }
    private val sessions = mutableMapOf<UUID, Session>()

    fun readDefinitions(): Map<String, NpcDialogue> {
        val firstRun = !Files.exists(directory)
        Files.createDirectories(directory)
        if (firstRun) for (example in listOf(NpcDialogue.merchant("vendedor"), NpcDialogue.battle("treinador"))) {
            val file = directory.resolve("${example.id}.json")
            if (!Files.exists(file)) mod.store.write(file, example)
        }
        return Files.list(directory).use { paths ->
            paths.filter { Files.isRegularFile(it) && it.fileName.toString().endsWith(".json") }.sorted().toList()
        }.associate { path ->
            val value = requireNotNull(mod.store.read(path, NpcDialogue::class.java) {
                it.validate(); require(path.fileName.toString() == "${it.id}.json") { "Nome do arquivo deve acompanhar o ID do diálogo" }
            })
            value.id to value
        }
    }
    fun validateBindings(records: Map<String, TrainerNpc>, next: Map<String, NpcDialogue>) {
        records.values.filterNot { it.removed }.forEach { r ->
            require(r.dialogue == null || r.dialogue in next) { "Diálogo ${r.dialogue} do NPC ${r.id} inexistente" }
        }
    }
    fun install(next: Map<String, NpcDialogue>) {
        sessions.values.toList().forEach(::retire)
        definitions = next.toMap()
    }
    fun reload() { val next = readDefinitions(); validateBindings(npcs.records, next); install(next) }
    fun create(id: String, example: String) {
        require(validId(id)) { "ID de diálogo inválido" }
        val path = directory.resolve("$id.json")
        require(!Files.exists(path)) { "Diálogo já existe; edite o JSON e use dialogue-reload" }
        val value = when (example) {
            "merchant", "loja" -> NpcDialogue.merchant(id)
            "battle", "batalha" -> NpcDialogue.battle(id)
            else -> error("Modelo: merchant ou battle")
        }
        value.validate(); mod.store.write(path, value); reload()
    }
    fun register() {
        ServerPlayConnectionEvents.DISCONNECT.register { handler, _ -> sessions[handler.player.uuid]?.let(::retire) }
        ServerLifecycleEvents.SERVER_STOPPING.register { sessions.values.toList().forEach(::retire) }
        ServerTickEvents.END_SERVER_TICK.register { server ->
            if (server.tickCount % 20 == 0) sessions.values.toList().filter { session ->
                !valid(session) || DialogueManager.activeDialogues[session.player.uuid] !== session.active
            }.forEach(::retire)
        }
    }
    private fun valid(s: Session): Boolean =
        sessions[s.player.uuid] === s && System.nanoTime() < s.deadline &&
        mod.server.playerList.getPlayer(s.player.uuid) === s.player && s.player.isAlive && !s.player.isSpectator &&
        s.npc.isAlive && !s.npc.isRemoved && !s.npc.isInBattle() &&
        s.player.serverLevel() === s.npc.level() && s.npc.distanceToSqr(s.player) <= 64.0 &&
        npcs.records[s.binding.id] == s.binding && !s.binding.removed && definitions[s.definition.id] == s.definition

    private fun source(player: ServerPlayer, executor: String) = if (executor == "player") player.createCommandSourceStack()
        else mod.server.createCommandSourceStack().withPermission(4).withLevel(player.serverLevel()).withPosition(player.position())
    private fun canUse(s: Session, b: NpcDialogueButton): Boolean {
        if (!valid(s) || (b.permission?.let { !Permissions.check(s.player, it, false) } == true)) return false
        return when (b.action) {
            "command" -> {
                val command = NpcClickCommand(b.executor, requireNotNull(b.command)).render(s.player.scoreboardName, s.player.uuid)
                val parsed = mod.server.commands.dispatcher.parse(command, source(s.player, b.executor))
                !parsed.reader.canRead() && parsed.context.build(command).lastChild.command != null
            }
            "battle" -> (b.trainer ?: s.binding.trainer)?.let { mod.trainers[it]?.enabled } == true
            else -> true
        }
    }
    private fun text(raw: String, s: Session) = formattedNpcName(raw
        .replace("%player%", s.player.scoreboardName).replace("%player_uuid%", s.player.uuid.toString())
        .replace("%npc%", s.npc.name.string)).copy()

    fun open(player: ServerPlayer, binding: TrainerNpc, npc: NPCEntity) {
        val definition = definitions[binding.dialogue] ?: error("Diálogo não configurado/carregado")
        require(player.isAlive && !player.isSpectator && player.serverLevel() === npc.level() && npc.isAlive && !npc.isInBattle()
            && npc.distanceToSqr(player) <= 64.0) { "Aproxime-se de um NPC disponível" }
        if (player.containerMenu !== player.inventoryMenu) player.closeContainer()
        sessions[player.uuid]?.let(::retire)
        // A player deliberately opening a new conversation replaces the previous native dialogue.
        DialogueManager.activeDialogues[player.uuid]?.close()
        val session = Session(player, npc, binding, definition)
        sessions[player.uuid] = session
        val close = FunctionDialogueAction { _, _ -> retire(session) }
        val pages = definition.pages.sortedBy { if (it.id == definition.startPage) 0 else 1 }.map { page ->
            DialoguePage().apply {
                id = page.id; speaker = page.speaker
                lines = page.text.split('\n').map<String, DialogueText> { WrappedDialogueText(text(it, session)) }.toMutableList()
                escapeAction = close
                input = DialogueOptionSetInput().apply {
                    vertical = page.vertical || page.buttons.size > 3
                    options = page.buttons.map { button ->
                        DialogueOption(
                            value = "${page.id}:${button.id}",
                            text = WrappedDialogueText(this@NpcDialogues.text(button.label, session)),
                            action = FunctionDialogueAction { active, _ -> select(session, active, page.id, button.id) },
                            isSelectable = FunctionDialoguePredicate { canUse(session, button) }
                        )
                    }.toMutableList()
                }
            }
        }
        val title = if (definition.title.isBlank()) npc.name.copy() else text(definition.title, session)
        val dialogue = Dialogue(pages = pages, speakers = mapOf(
            "npc" to DialogueSpeaker(name = WrappedDialogueText(title), face = ReferenceDialogueFaceProvider(npc.id, false)),
            "player" to DialogueSpeaker(name = WrappedDialogueText(Component.literal(player.scoreboardName)), face = PlayerDialogueFaceProvider(player.uuid, true))
        ), escapeAction = close)
        try {
            val active = DialogueManager.startDialogue(player, npc, dialogue)
            session.active = active
            active.completion.whenComplete { _, _ -> sessions.remove(player.uuid, session) }
        } catch (error: Exception) { retire(session); throw error }
    }
    private fun select(s: Session, active: ActiveDialogue, pageId: String, buttonId: String) {
        if (!mod.server.isSameThread) { mod.server.execute { select(s, active, pageId, buttonId) }; return }
        // Also guards Cobblemon callbacks after a disabled option closes a dialogue, and stale/replayed inputs.
        if (sessions[s.player.uuid] !== s || s.active !== active || active.completion.isDone ||
            DialogueManager.activeDialogues[s.player.uuid] !== active) return
        try {
            require(valid(s) && active.currentPage?.id == pageId) { "Conversa expirada ou NPC alterado; fale novamente com ele" }
            val button = s.definition.pages.single { it.id == pageId }.buttons.single { it.id == buttonId }
            require(canUse(s, button)) { "Opção indisponível ou sem permissão" }
            val now = System.nanoTime()
            if (now - s.lastAction < TimeUnit.MILLISECONDS.toNanos(250)) return
            s.lastAction = now
            if (button.action == "page") {
                s.deadline = now + TimeUnit.SECONDS.toNanos(s.definition.timeoutSeconds.toLong())
                active.setPage(active.dialogueReference.pages.indexOfFirst { it.id == button.page })
                return
            }
            // Consume before the terminal action. Opening an inventory must not be followed by a dialogue close.
            retire(s)
            when (button.action) {
                "command" -> {
                    val configured = NpcClickCommand(button.executor, requireNotNull(button.command))
                    mod.audit(s.player.scoreboardName, "npc dialogue ${s.binding.id} ${s.definition.id} $pageId $buttonId ${button.executor}")
                    mod.server.commands.performPrefixedCommand(source(s.player, button.executor), configured.render(s.player.scoreboardName, s.player.uuid))
                }
                "battle" -> npcs.dialogueBattle(s.player, s.binding.id, s.npc.uuid, button.trainer)
                "close" -> Unit
            }
        } catch (error: Exception) {
            retire(s); s.player.sendSystemMessage(Component.literal("§c${error.message}"))
        }
    }
    private fun retire(session: Session) {
        sessions.remove(session.player.uuid, session)
        val active = session.active ?: return
        if (!active.completion.isDone) {
            // ActiveDialogue.close() operates on the player's current manager entry. Never close a replacement owned by another mod.
            if (DialogueManager.activeDialogues[session.player.uuid] === active) runCatching { active.close() }
            DialogueManager.activeDialogues.remove(session.player.uuid, active)
            active.completion.complete(Unit)
        }
    }
}

"""Run the local native Cobblemon dialogue + Zorykai-menu TCP integration suite."""
from pathlib import Path
import os,json,secrets,subprocess,time,urllib.parse,sys
repo=Path(__file__).resolve().parents[1];runtime=Path(sys.argv[1]).resolve()
assert runtime.name.startswith('trainers-dialogue-test-') and (runtime/'mods/zorykai-dialogue-test.jar').exists()
env=os.environ.copy();env.update(MC_TEST_ROOT=str(runtime),MC_RCON_PORT='25598',MC_RCON_PASSWORD=secrets.token_urlsafe(24),MC_RCON_HELPER=str(repo/'tools/dialogue_rcon.py'),MC_PROTOCOL_MODULE='/workspace/Shirokai-Pass/tools/smoke/node_modules/minecraft-protocol')
with (runtime/'server.properties').open('a') as f:f.write('enable-rcon=true\nrcon.port=25598\nrcon.password='+env['MC_RCON_PASSWORD']+'\n')
jvm=[]
for scheme in ['http','https']:
 p=urllib.parse.urlsplit(env.get(scheme.upper()+'_PROXY',''))
 if p.hostname:jvm+=['-D'+scheme+'.proxyHost='+p.hostname,'-D'+scheme+'.proxyPort='+str(p.port or 80)]
jvm+=['-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts','-Dhttp.nonProxyHosts=localhost|127.*|[::1]']
p=c=None
try:
 with (runtime/'server.log').open('w') as log:
  p=subprocess.Popen(['/workspace/shared/jdk/bin/java',*jvm,'-Xms512M','-Xmx3G','-Xverify:all','-Dzorykai.dialogueTest=true','-jar','fabric-server-launch.jar','nogui'],cwd=runtime,stdout=log,stderr=subprocess.STDOUT)
  deadline=time.monotonic()+200
  while 'Done (' not in (runtime/'server.log').read_text(errors='replace'):
   if p.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Server did not become ready; inspect '+str(runtime/'server.log'))
   time.sleep(.25)
  with (runtime/'client.log').open('w') as cl:
   c=subprocess.Popen(['node',str(repo/'tools/test_dialogue.cjs')],env=env,cwd=repo,stdout=cl,stderr=subprocess.STDOUT)
   assert c.wait(timeout=200)==0,'TCP suite failed; inspect '+str(runtime/'client.log')
  subprocess.run(['python3',env['MC_RCON_HELPER'],'stop'],env=env,stdout=subprocess.DEVNULL,check=True);assert p.wait(timeout=60)==0
  result=json.loads((runtime/'dialogue-test-result.json').read_text());assert result['passed'];print(json.dumps(result,ensure_ascii=False),flush=True)
finally:
 if c and c.poll() is None:c.terminate();c.wait(timeout=20)
 if p and p.poll() is None:p.terminate();p.wait(timeout=60)
